package com.wx.wanda.csinterface.entity;

import java.util.Arrays;

public class Community {
		
		private String id;
		private String orgId;
		private String commuId;
		private String yeTai;
		private String commuName;
		/**
		 * @return the id
		 */
		public String getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			this.id = id;
		}
		/**
		 * @return the orgId
		 */
		public String getOrgId() {
			return orgId;
		}
		/**
		 * @param orgId the orgId to set
		 */
		public void setOrgId(String orgId) {
			this.orgId = orgId;
		}
		/**
		 * @return the commuId
		 */
		public String getCommuId() {
			return commuId;
		}
		/**
		 * @param commuId the commuId to set
		 */
		public void setCommuId(String commuId) {
			this.commuId = commuId;
		}
		/**
		 * @return the yeTai
		 */
		public String getYeTai() {
			return yeTai;
		}
		/**
		 * @param yeTai the yeTai to set
		 */
		public void setYeTai(String yeTai) {
			this.yeTai = yeTai;
		}
		/**
		 * @return the commuName
		 */
		public String getCommuName() {
			return commuName;
		}
		/**
		 * @param commuName the commuName to set
		 */
		public void setCommuName(String commuName) {
			this.commuName = commuName;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Community [id=" + id + ", orgId=" + orgId + ", commuId="
					+ commuId + ", yeTai=" + yeTai + ", commuName=" + commuName
					+ "]";
		}
		
		
}
