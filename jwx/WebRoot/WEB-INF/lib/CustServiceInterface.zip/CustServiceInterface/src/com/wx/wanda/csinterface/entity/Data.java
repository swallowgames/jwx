package com.wx.wanda.csinterface.entity;

public class Data {
	
	private String description;
	
	private String sheetNo;

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the sheetNo
	 */
	public String getSheetNo() {
		return sheetNo;
	}

	/**
	 * @param sheetNo the sheetNo to set
	 */
	public void setSheetNo(String sheetNo) {
		this.sheetNo = sheetNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Data [description=" + description + ", sheetNo=" + sheetNo
				+ "]";
	}
	
	
}
