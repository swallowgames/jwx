package com.wx.wanda.csinterface.entity;

/**
 * 报修工单列表项实例
 * @author kuangxi
 *
 */
public class RepairInfo {
		
	/**
	 * 接口返回数据样例：
	 * {total:6,
	 * data:[{
	 * id:'8a47d2f54d2e01d4014d311751530120',
	 * cus_id:'8a47d2ca4d1e0386014d2cea38e91a03',
	 * member_id:'8a47d2f54d2e01d12233431',
	 * title:'小区水管漏水',
	 * yetai_id:'101',
	 * yetai_name:'物管',
	 * org_id:'102',
	 * org_name:'物管',
	 * commu_id:'8a47d2f64d26e01e014d2c24c59a08de',
	 * commu_name:'玉园小区',
	 * building_ID:'103',
	 * building_name:'13号楼',
	 * unit_id:'104',
	 * unit_name:'一单元',
	 * room_id:'105',
	 * room_name:'1304',
	 * area:'海淀区',
	 * addr:'分台北楼',
	 * DESCRIPTION:'8a47d2f54d2e01d12233431',
	 * STATUS:'已处理'}]
	 * }
	 */
	private String id;
	private String cus_id;
	private String member_id;
	private String title;
	private String yetai_id;
	private String yetai_name;
	private String org_id;
	private String org_name;
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RepairInfo [id=" + id + ", cus_id=" + cus_id + ", member_id="
				+ member_id + ", title=" + title + ", yetai_id=" + yetai_id
				+ ", yetai_name=" + yetai_name + ", org_id=" + org_id
				+ ", org_name=" + org_name + ", commu_id=" + commu_id
				+ ", commu_name=" + commu_name + ", building_ID=" + building_ID
				+ ", building_name=" + building_name + ", unit_id=" + unit_id
				+ ", unit_name=" + unit_name + ", room_id=" + room_id
				+ ", room_name=" + room_name + ", area=" + area + ", addr="
				+ addr + ", DESCRIPTION=" + DESCRIPTION + ", STATUS=" + STATUS
				+ "]";
	}
	private String commu_id;
	private String commu_name;
	private String building_ID;
	private String building_name;
	private String unit_id;
	private String unit_name;
	private String room_id;
	private String room_name;
	private String area;
	private String addr;
	private String DESCRIPTION;
	private String STATUS;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the cus_id
	 */
	public String getCus_id() {
		return cus_id;
	}
	/**
	 * @param cus_id the cus_id to set
	 */
	public void setCus_id(String cus_id) {
		this.cus_id = cus_id;
	}
	/**
	 * @return the member_id
	 */
	public String getMember_id() {
		return member_id;
	}
	/**
	 * @param member_id the member_id to set
	 */
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the yetai_id
	 */
	public String getYetai_id() {
		return yetai_id;
	}
	/**
	 * @param yetai_id the yetai_id to set
	 */
	public void setYetai_id(String yetai_id) {
		this.yetai_id = yetai_id;
	}
	/**
	 * @return the yetai_name
	 */
	public String getYetai_name() {
		return yetai_name;
	}
	/**
	 * @param yetai_name the yetai_name to set
	 */
	public void setYetai_name(String yetai_name) {
		this.yetai_name = yetai_name;
	}
	/**
	 * @return the org_id
	 */
	public String getOrg_id() {
		return org_id;
	}
	/**
	 * @param org_id the org_id to set
	 */
	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}
	/**
	 * @return the org_name
	 */
	public String getOrg_name() {
		return org_name;
	}
	/**
	 * @param org_name the org_name to set
	 */
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	/**
	 * @return the commu_id
	 */
	public String getCommu_id() {
		return commu_id;
	}
	/**
	 * @param commu_id the commu_id to set
	 */
	public void setCommu_id(String commu_id) {
		this.commu_id = commu_id;
	}
	/**
	 * @return the commu_name
	 */
	public String getCommu_name() {
		return commu_name;
	}
	/**
	 * @param commu_name the commu_name to set
	 */
	public void setCommu_name(String commu_name) {
		this.commu_name = commu_name;
	}
	/**
	 * @return the building_ID
	 */
	public String getBuilding_ID() {
		return building_ID;
	}
	/**
	 * @param building_ID the building_ID to set
	 */
	public void setBuilding_ID(String building_ID) {
		this.building_ID = building_ID;
	}
	/**
	 * @return the building_name
	 */
	public String getBuilding_name() {
		return building_name;
	}
	/**
	 * @param building_name the building_name to set
	 */
	public void setBuilding_name(String building_name) {
		this.building_name = building_name;
	}
	/**
	 * @return the unit_id
	 */
	public String getUnit_id() {
		return unit_id;
	}
	/**
	 * @param unit_id the unit_id to set
	 */
	public void setUnit_id(String unit_id) {
		this.unit_id = unit_id;
	}
	/**
	 * @return the unit_name
	 */
	public String getUnit_name() {
		return unit_name;
	}
	/**
	 * @param unit_name the unit_name to set
	 */
	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}
	/**
	 * @return the room_id
	 */
	public String getRoom_id() {
		return room_id;
	}
	/**
	 * @param room_id the room_id to set
	 */
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	/**
	 * @return the room_name
	 */
	public String getRoom_name() {
		return room_name;
	}
	/**
	 * @param room_name the room_name to set
	 */
	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return the addr
	 */
	public String getAddr() {
		return addr;
	}
	/**
	 * @param addr the addr to set
	 */
	public void setAddr(String addr) {
		this.addr = addr;
	}
	/**
	 * @return the dESCRIPTION
	 */
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	/**
	 * @param dESCRIPTION the dESCRIPTION to set
	 */
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	/**
	 * @return the sTATUS
	 */
	public String getSTATUS() {
		return STATUS;
	}
	/**
	 * @param sTATUS the sTATUS to set
	 */
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	
	
	
//		//工单编号
//		private String sheetId;
//		//报修内容
//		private String content;
//		//受理时间
//		private String acceptDate;
//		//受理人
//		private String acceptName;
//		//状态
//		private String state;
//		//责任人
//		private String curResPerson;
//		//责任人联系电话
//		private String resPersonTel;
//		
		
}
