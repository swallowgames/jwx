package com.wx.wanda.csinterface.entity;

public class RepairTrace {
		
		//处理人
		private String resPersonName;
		//处理人电话
		private String resPersonTel;
		//处理时间
		private String resDate;
		//处理人填写内容
		private String content;
		
		public String getResPersonName() {
				return resPersonName;
		}
		
		public void setResPersonName(String resPersonName) {
				this.resPersonName = resPersonName;
		}
		
		public String getResPersonTel() {
				return resPersonTel;
		}
		
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RepairTrace [resPersonName=" + resPersonName
					+ ", resPersonTel=" + resPersonTel + ", resDate=" + resDate
					+ ", content=" + content + "]";
		}

		public void setResPersonTel(String resPersonTel) {
				this.resPersonTel = resPersonTel;
		}
		
		public String getResDate() {
				return resDate;
		}
		
		public void setResDate(String resDate) {
				this.resDate = resDate;
		}
		
		public String getContent() {
				return content;
		}
		
		public void setContent(String content) {
				this.content = content;
		}

}
