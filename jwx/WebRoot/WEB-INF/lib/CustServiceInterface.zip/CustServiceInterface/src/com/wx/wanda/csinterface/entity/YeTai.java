package com.wx.wanda.csinterface.entity;

public class YeTai {
		
	
	/**
	 * 接口返回数据样例；
	 * [{yetaiId:'8a47d2cc0c16c0014c0c5b13e2020e',yetaiName:'百货'}]
	 */
		private String yetaiId;
		private String yetaiName;
//		private Org[] orgs;
		/**
		 * @return the yetaiId
		 */
		public String getYetaiId() {
			return yetaiId;
		}
		/**
		 * @param yetaiId the yetaiId to set
		 */
		public void setYetaiId(String yetaiId) {
			this.yetaiId = yetaiId;
		}
		/**
		 * @return the yetaiName
		 */
		public String getYetaiName() {
			return yetaiName;
		}
		/**
		 * @param yetaiName the yetaiName to set
		 */
		public void setYetaiName(String yetaiName) {
			this.yetaiName = yetaiName;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "YeTai [yetaiId=" + yetaiId + ", yetaiName=" + yetaiName
					+ "]";
		}
		
		
}
