package com.wx.wanda.csinterface.service;

import java.util.ArrayList;
import java.util.List;

import javax.sql.CommonDataSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.log4j.Logger;

import com.wx.wanda.csinterface.entity.Building;
import com.wx.wanda.csinterface.entity.Community;
import com.wx.wanda.csinterface.entity.CommunityInfo;
import com.wx.wanda.csinterface.entity.Customer;
import com.wx.wanda.csinterface.entity.Data;
import com.wx.wanda.csinterface.entity.Org;
import com.wx.wanda.csinterface.entity.Repair;
import com.wx.wanda.csinterface.entity.RepairInfo;
import com.wx.wanda.csinterface.entity.Room;
import com.wx.wanda.csinterface.entity.Unit;
import com.wx.wanda.csinterface.entity.YeTai;
import com.wx.wanda.csinterface.util.HttpWebResponseUtility;
import com.wx.wanda.csinterface.util.JsonUtil;
import com.wx.wanda.csinterface.util.URL1;

public class Service {
		
		private static Logger logger = Logger.getLogger(Service.class);
		
		/***
		 * 关注(订阅)
		 * openid、wxaccount 不能为NULL或空字符串
		 * @param openid : 公众号内粉丝唯一ID
		 * @param wxaccount: 微信公众号账号
		 * @param nickname: 昵称
		 * @param unionid : 开放平台绑定后 粉丝统一ID
		 * @param province : 省 
		 * @param county : 国家
		 * @param city : 市
		 * @param descri : 描述
		 * @param picurl : 头像图片地址
		 * @param sex : 性别
		 * @param lang : 用户的语言
		 * @return 成功返回客户唯一ID，失败返回null
		 */
		public static String subscribe(String openid,
				 										   String wxaccount,
				 										   String nickname,
				 									  	   String unionid,
				 										   String province,
				 										   String county,
				 										   String city,
				 										   String descri,
				 										   String picurl,
				 										   String sex,
				 										   String lang){
				String parameters = "" ;
				String returnVal = "";
				
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
				
				parameters += "?openid=" + openid + "&wxaccount=" + wxaccount;
				parameters +="&" + addParameter("nickname",nickname);
				parameters +="&" + addParameter("unionid",unionid);
				parameters +="&" + addParameter("province",province);
				parameters +="&" + addParameter("county",county);
				parameters +="&" + addParameter("city",city);
				parameters +="&" + addParameter("picurl",picurl);
				parameters +="&" + addParameter("sex",sex);
				parameters +="&" + addParameter("lang",lang);
				
//				returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_SUBSCRIBE + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
				returnVal = "{\"success\":true,\"data\":\"8a4749074db4244d014db42453180000\"}";
				logger.info("response : " + returnVal);
				
				if(returnVal != null && returnVal.contains("success")) {
					JSONObject object = JSONObject.fromObject(returnVal);
					String s = object.getString("data");
					return s.equals("null") ? null : s;
					
				}
				return null;
		}
		
		/**
		 * 取消关注(订阅)
		 * openid、wxaccount 不能为NULL或空字符串
		 * @param openid : 公众号内粉丝唯一ID
		 * @param wxaccount: 公众号账号
		 * @return true : 接口处理成功, false : 接口处理失败
		 */
		public static boolean unsubscribe(String openid,
						 											 String wxaccount){
				
				String parameters = "" ;
				String returnVal = "";
				
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return false;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return false;
				}
				
				parameters += "?openid=" + openid + "&wxaccount=" + wxaccount;
				
//				returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_UNSUBSCRIBE + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
				returnVal = "{\"success\":true}";
				
				logger.info("response : " + returnVal);
				//解析返回的Json字符串，返回true或false
				if(returnVal != null && returnVal.contains("success")) {
					return true;
				}
				return true;
		}
		
		/***
		 * 注册
		 * openid、cusid、cusname、mobile 不能为NULL或空字符串
		 * @param wxaccount: 微信公众号账号
		 * @param openid : 公众号内粉丝唯一ID
		 * @param cusid: 客户唯一ID
		 * @param cusname: 客户姓名
		 * @param mobile : 客户手机号
		 * @return true : 接口处理成功, false : 接口处理失败
		 */
		public static boolean register(String openid,
															 String wxaccount,
                                    						 String cusname,
                                    						 String mobile){
                String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return false;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return false;
				}
				
				if(isNULL(cusname)){
						logger.error("input parameter error. cusname is null ");
						return false;
				}
				
				if(isNULL(mobile)){
						logger.error("input parameter error. mobile is null ");
						return false;
				}
                
                parameters += "?openid=" + openid + "&wxaccount=" + wxaccount + "&cusname=" + cusname + "&mobile=" + mobile;
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_REGISTER + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "{\"success\":true}";
                logger.info("response : " + returnVal);
                
                if(returnVal != null && returnVal.contains("success")){
                		return true;
                }

                return false;
		}
		
		/**
		 * 绑定
		 * @param wxaccount: 微信公众号账号
		 * @param openid : 公众号内粉丝唯一ID
		 * @param yetaiid : 业态编号
		 * @param orgid : 机构门店编号（组团ID？）
		 * @param building : 楼栋编号
		 * @param unit : 单元编号
		 * @param room : 房屋编号
		 * @param username : 姓名
		 * @param mobile : 手机号
		 * @return :  成功返回 会员唯一号 失败 返回 NULL 
		 */
		public static String bind(String openid,
											      String wxaccount,
                        					  	  String yetaiid,
                        						  String orgid,
                        						  String building,
                        						  String unit,
                        						  String room,
                        						  String username,
                        						  String mobile){
                
				String memberid = null;
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
				
				if(isNULL(yetaiid)){
						logger.error("input parameter error. yetaiid is null ");
						return null;
				}
				
				if(isNULL(orgid)){
						logger.error("input parameter error. orgid is null ");
						return null;
				}
				
				if(isNULL(building)){
						logger.error("input parameter error. building is null ");
						return null;
				}
				
				if(isNULL(unit)){
						logger.error("input parameter error. unit is null ");
						return null;
				}
				
				if(isNULL(room)){
						logger.error("input parameter error. room is null ");
						return null;
				}
				
				if(isNULL(username)){
						logger.error("input parameter error. username is null ");
						return null;
				}
				
				if(isNULL(mobile)){
						logger.error("input parameter error. mobile is null ");
						return null;
				}
                
                parameters += "?openid=" + openid + "&wxaccount=" + wxaccount + "&yetaiid=" + yetaiid + "&orgid=" + orgid + "&building=" + building + "&unit=" + unit + "&room=" + room + "&username=" + username +"&mobile=" + mobile;
               
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_BIND + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "{\"success\":true,\"data\":\"8a4749074db4244d014db42f60250002\"}";
                //{"success":true,"data":"8a4749074db4244d014db42f60250002"}
                logger.info("response : " + returnVal);
                if(returnVal != null && returnVal.contains("success")){
                	
                	JSONObject jsonObject = JSONObject.fromObject(returnVal);
                	memberid = jsonObject.getString("data");
                }

                return memberid;
		}
		
		/**
		 * 取消绑定
		 * @param wxaccount: 微信公众号账号
		 * @param openid : 公众号内粉丝唯一ID
		 * @return
		 */
		public static boolean unbind(String openid,	String wxaccount){
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return false;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return false;
				}
				
				parameters += "?openid=" + openid + "&wxaccount=" + wxaccount ;

                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_UNBIND + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                //{"success":true}
                returnVal = "{\"success\":true}";
                logger.info("response : " + returnVal);
                if(returnVal != null && returnVal.contains("success")){
                		return true;
                }

                return false;
		}
		
		/**
		 * 会员资料查询
		 * @param wxaccount: 微信公众号账号
		 * @param openid : 公众号内粉丝唯一ID
		 * @param memberid : 会员ID
		 * @return 客户对象 或 NULL
		 */
		public static Customer getCustomerInfo(String openid,
																			 String wxaccount,
																			 String memberid){
				
				Customer customer = null;
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
				
				parameters += "?openid=" + openid + "&wxaccount=" + wxaccount ;
				parameters +="&" + addParameter("memberid",memberid);
				
//                returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_QUERY + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "{\"success\":true,\"data\":{\"id\":\"8a4749074db4244d014db42f60250002\",\"username\":\"5\",\"mobile\":\"6\",\"building\":\"3\",\"unit\":\"4\",\"room\":\"5\",\"yetaiid\":\"1\",\"orgid\":\"2\"}}";
                
                logger.info("response : " + returnVal);
                if(returnVal.indexOf("success") != -1 && returnVal.indexOf("data") != -1) {
                	JSONObject object = JSONObject.fromObject(returnVal);
                	String cus_info = object.getString("data");
                	customer = (Customer) JsonUtil.getObject(cus_info, Customer.class);
                	return customer;
                }
                return null;
        }
		
		/**
		 * 客户资料更新
		 * @param wxaccount: 微信公众号账号
		 * @param openid : 公众号内粉丝唯一ID
		 * @param memberid : 会员ID
		 * @param yetaiid : 业态编号
		 * @param orgid : 机构门店编号（组团ID？）
		 * @param building : 楼栋编号
		 * @param unit : 单元编号
		 * @param room : 房屋编号
		 * @param username : 姓名
		 * @param mobile : 手机号
		 * @return
		 */
		public static boolean updateCustomerInfo(String openid,
																				  String wxaccount,
																				  String memberid,
																				  String yetaiid,
							                                					  String orgid,
							                                				      String building,
							                                					  String unit,
							                                					  String room, 
							                                					  String username,
							                                					  String mobile){
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return false;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return false;
				}
				
				
				
				if(isNULL(username)){
						logger.error("input parameter error. username is null ");
						return false;
				}
				
				if(isNULL(mobile)){
						logger.error("input parameter error. mobile is null ");
						return false;
				}
				
				parameters += "?openid=" + openid + "&Memberid=" + memberid + "&wxaccount=" + wxaccount + "&username=" +username + "&mobile=" + mobile ;
				
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_CUST_UPDATE + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
				returnVal = "{\"success\":true,\"data\":{\"id\":\"8a4749074db4244d014db42f60250002\",\"username\":\"3\",\"level\":\"BIND\",\"mobile\":\"2\",\"unit\":\"4\"}}";
				//{"success":true,"data":{"id":"8a4749074db4244d014db42f60250002","username":"3","level":"BIND","mobile":"2","unit":"4"}}
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                if(returnVal != null && returnVal.contains("success")) {
                	return true;
                }
				return false;
		}
		
		/**
		 * 获取小区列表
		 * @return
		 */
		public static CommunityInfo[] getCommunityList(){
				
				CommunityInfo[] communityInfoList = null;
                String returnVal = "";
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_LIST_QUERY , HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{\"id\":\"1\",\"name\":\"北京玉园\",\"wxNo\":\"wxaccount1\"}]";
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                //[{"id":"1","name":"北京玉园","wxNo":"wxaccount1"}]
                if(returnVal.indexOf("id") != -1) {
                	  JSONArray jsonArray = JsonUtil.getJSONArray(returnVal);
                      communityInfoList = new CommunityInfo[jsonArray.size()];
      				for(int i=0;i<jsonArray.size();i++){
      						communityInfoList[i] = (CommunityInfo)JsonUtil.getObject(jsonArray.getString(i),CommunityInfo.class);
      				}
                }
              

				return communityInfoList;
		}
		
		/**
		 * 绑定小区微信号与小区ID（客诉平台创建小区）
		 * @param communityid : 会员ID
		 * @param wxaccount : 微信公众号ID
		 * @return 成功 true，失败 false
		 */
		public static boolean createCommunity(String communityid,
																			  String wxaccount){

				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(communityid)){
						logger.error("input parameter error. communityid is null ");
						return false;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return false;
				}
				
				parameters += "?wxaccount=" + wxaccount + "&commuid=" + communityid ;
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_CREATE + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "{\"success\":\"true\"}";  
                logger.info("response : " + returnVal);
                if(returnVal != null && returnVal.contains("success")){
                		return true;
                }

                return false;
		}
		
		/**
		 *  根据小区id与微信公众号id获取小区详细信息
		 * @param communityid : 会员ID
		 * @param wxaccount : 微信公众号ID
		 * @return 小区详细信息
		 */
		public static Community getCommunityDetail(String communityid,
																				     String wxaccount){
				Community community = null;
				String parameters = "" ;
                String returnVal = "";
               
				if(isNULL(communityid)){
						logger.error("input parameter error. communityid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
				
				parameters += "?wxaccount=" + wxaccount + "&commuid=" + communityid ;
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_DETAIL + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
				returnVal = "{\"orgId\":\"1\",\"id\":\"1\",\"commuId\":\"4\",\"yeTai\":\"1\",\"commuName\":\"玉园小区\"}";
                logger.info("response : " + returnVal);
                community = (Community) JsonUtil.getObject(returnVal, Community.class);
                return community;
		}
		
		/**
		 * 创建工单
		 * @param communityid : 会员ID
		 * @param wxaccount : 微信公众号ID
		 * @param openid : 公众号内粉丝唯一ID
		 * @param title : 报修工单标题
		 * @param descri : 报修工单描述
		 * @param area : 报修区域
		 * @param addr : 报修地址
		 * @return String 工单号
		 */
		public static String createRepair(String memberid,
						                                              String openid,
						                                              String wxaccount,
						                                              String title,
						                                              String descri,
						                                              String area,
						                                              String addr){
				
				String parameters = "" ;
                String returnVal = "";
               
				if(isNULL(memberid)){
						logger.error("input parameter error. memberid is null ");
						return null;
				}
				
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
				
				if(isNULL(descri)){
						logger.error("input parameter error. descri is null ");
						return null;
				}
				
				if(isNULL(area)){
						logger.error("input parameter error. area is null ");
						return null;
				}
				
				parameters += "?Memberid=" + memberid + "&openid=" + openid + "&wxaccount=" + wxaccount + "&descri=" + descri + "&area=" + area;
				parameters +="&" + addParameter("title",title);
				parameters +="&" + addParameter("addr",addr);
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_REPAIR_CREATE + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
				returnVal = "{\"sheetId\":\"8a4749074db435ca014db439640d0002\",\"success\":true}";
				//{"sheetId":"8a4749074db435ca014db439640d0002","success":true}
                logger.info("response : " + returnVal);
                
                //解析返回的Json字符串
                if(returnVal != null && returnVal.contains("success")) {
                	JSONObject object = JSONObject.fromObject(returnVal);
					return object.getString("sheetId");
                }
				return null;
		}
		
		/**
		 * 根据openid与微信公众号账号查询报修工单列表
		 * @param openid : 公众号内粉丝唯一ID
		 * @param wxaccount: 微信公众号账号
		 * @return
		 */
		public static RepairInfo[] getRepairInfoList(String openid,
						   										                String wxaccount){
				RepairInfo[] repairs = null;
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(openid)){
						logger.error("input parameter error. openid is null ");
						return null;
				}
				
				if(isNULL(wxaccount)){
						logger.error("input parameter error. wxaccount is null ");
						return null;
				}
                
				parameters += "?openid=" + openid + "&wxaccount=" + wxaccount;
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_REPAIR_QUERY_LIST + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "{\"total\":1,\"data\":[{\"org_id\":\"1\",\"id\":\"8a813fa14db40ef9014db40ef9de0000\",\"title\":\"1\",\"area\":\"1\",\"DESCRIPTION\":\"1\",\"room_id\":\"203\",\"unit_id\":\"1\",\"STATUS\":\"GW_WCL\",\"building_ID\":\"1\",\"member_id\":\"8a813fa14db3d060014db3f1345d0000\"}]}";
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                //{"total":1,"data":[{"org_id":"1","id":"8a813fa14db40ef9014db40ef9de0000","title":"1","area":"1","DESCRIPTION":"1","room_id":"203","unit_id":"1","STATUS":"GW_WCL","building_ID":"1","member_id":"8a813fa14db3d060014db3f1345d0000"}]}

                if(returnVal.indexOf("total") != -1 && returnVal.indexOf("data") != -1) {
                	JSONObject object = JSONObject.fromObject(returnVal);
                	String repair_data = object.getString("data");
                	JSONArray array = JSONArray.fromObject(repair_data);
                	repairs = new RepairInfo[array.size()];
                	if(array.size() > 0) {
                		for (int i = 0; i < array.size(); i++) {
							repairs[i] = (RepairInfo) JsonUtil.getObject(array.getString(i), RepairInfo.class);
						}
                	}
                }
				return repairs;
		}
		
		/**
		 * 通过工单编号获取工单详情
		 * @param sheetid : 工单编号
		 * @return Repair : 工单对象
		 */
		public static Repair getRepairDetail(String sheetid){
				
				Repair repair = null;
				String parameters = "" ;
                String returnVal = "";
                
				if(isNULL(sheetid)){
						logger.error("input parameter error. sheetid is null ");
						return null;
				}
				
				parameters += "?sheetid=" + sheetid;
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_REPAIR_QUERY_DETAIL + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                
                logger.info("response : " + returnVal);
                returnVal = "{\"data\":[{\"description\":\"ceshitestqqqqqq\",\"sheetNo\":\"dksjskdjaksj\"}],\"success\":true}";
                //解析返回的Json字符串
                //{"acceptDate":"2015-05-19 15:08:16","content":"龙湖区张先森的报修单","repairId":"1","repairTrace":[{"content":"修理修0号管道","resDate":"2015-05-19 15:08:16","resPersonName":"张0","resPersonTel":"13120123120"},{"content":"修理修1号管道","resDate":"2015-05-19 15:08:16","resPersonName":"张1","resPersonTel":"13121123121"},{"content":"修理修2号管道","resDate":"2015-05-19 15:08:16","resPersonName":"张2","resPersonTel":"13122123122"}]}
                if(returnVal.indexOf("success") != -1) {
                	repair = new Repair();
                	JSONObject object = JSONObject.fromObject(returnVal);
                	String repair_info = object.getString("data");
                	JSONArray array = JSONArray.fromObject(repair_info);
                	Data[] data = new Data[array.size()];
                	for (int i = 0; i < data.length; i++) {
						data[i] = (Data) JsonUtil.getObject(array.get(i).toString(), Data.class);
					}
                	repair.setData(data);
                }
				return repair;
		}
		
		/**
		 * 根据username（对应rtxid）获取响应的权限id列表
		 * @param rtxid
		 * @return
		 */
		public static ArrayList<String> getAuthListByRtxId(String rtxid){
				
				ArrayList<String> alAuth = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(rtxid)){
						logger.error("input parameter error. rtxid is null ");
						return null;
				}
				
				parameters += "?username=" + rtxid;
				
				//returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_USER_AUTH_LIST + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{\"resourceId\":\"8a47d2ca4a0b64fb014a0b7fc0890019\"},{\"resourceId\":\"8a47d2ca4a0b8a1f014a0baef016003e\"},{\"resourceId\":\"8a47d2ca4a0b8a1f014a0bafbeda003f\"}]";
                logger.info("response : " + returnVal);
                
                //解析返回的Json字符串
				if(returnVal.indexOf("resourceId") != -1) {
					JSONArray array = JSONArray.fromObject(returnVal);
					alAuth = new ArrayList<String>();
					for (int i = 0; i < array.size(); i++) {
						JSONObject object = JSONObject.fromObject(array.get(i));
						alAuth.add(object.getString("resourceId"));
					}
				}
                
                
				return alAuth;
		}
		
		/**
		 * 根据小区ID获取该小区下的所有业态
		 * @param communityId
		 * @return
		 */
		public static YeTai[] getYetaiByCommunityId(String communityId){
				
				YeTai[] yetai = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(communityId)){
						logger.error("input parameter error. communityId is null ");
						return null;
				}
                
                parameters += "?commuid=" + communityId;
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_YETAI + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{yetaiId:'8a47d2cc0c16c0014c0c5b13e2020e',yetaiName:'百货'},{yetaiId:'8a47d2ca4c0c16c0014c0c5b13e2020e',yetaiName:'院线'}]";
                logger.info("response : " + returnVal);
                try {
					JSONArray array = JSONArray.fromObject(returnVal);
					if(array.size() > 0) {
						yetai = new YeTai[array.size()];
						for (int i = 0; i < array.size(); i++) {
							yetai[i] = (YeTai) JsonUtil.getObject(array.get(i).toString(), YeTai.class);
						}
					}
					return yetai;
					
				} catch (Exception e) {
					 logger.info("response : " + returnVal);
					return null;
				}
		}
		
		/**
		 * 根据业态ID获取该业态下的所有组团
		 * @param yetaiId
		 * @return
		 */
		public static Org[] getOrgByYetaiId(String yetaiId){
				
				Org[] org = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(yetaiId)){
						logger.error("input parameter error. yetaiId is null ");
						return null;
				}
                
                parameters += "?yetaiid=" + yetaiId;
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_ORG + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{id:'8a47d2ca4c0c16c0014c0c5b13e2020e',orgName:'北京石景山万达广场',pId:'8a47d2ca4c0c16c0014c0c5b13e2020d',pName:'商管总部'}]";
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                JSONArray array = JSONArray.fromObject(returnVal);
                if(array.size() > 0) {
                	org = new Org[array.size()];
                	for (int i = 0; i < array.size(); i++) {
                		org[i] = (Org) JsonUtil.getObject(array.get(i).toString(), Org.class);
					}
                }
                
				return org;
		}
		
		/**
		 * 根据组团ID获取该组团下的所有楼栋
		 * @param orgId
		 * @return
		 */
		public static Building[] getBuildingByOrgId(String orgId){
				
				Building[] building = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(orgId)){
						logger.error("input parameter error. orgId is null ");
						return null;
				}
                
                parameters += "?orgid=" + orgId;
                
//                returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_BUILDING + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{id:'8a47d2cc0c16c0014c0c5b13e2020e',name:'2号楼'}, {id:'8a47d2ca4c0c10014c0c5b13e2020e',name:'1号楼'}]";
                logger.info("response : " + returnVal);
               
                JSONArray array = JSONArray.fromObject(returnVal);
                if(array.size() > 0) {
                	building = new Building[array.size()];
                	for (int i = 0; i < array.size(); i++) {
                		building[i] = (Building) JsonUtil.getObject(array.get(i).toString(), Building.class);
					}
                }
				return building;
		}
		
		/**
		 * 根据楼栋ID获取该楼栋下的所有单元
		 * @param buildingId
		 * @return
		 */
		public static Unit[] geUnitByBuildingId(String buildingId){
				
				Unit[] unit = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(buildingId)){
						logger.error("input parameter error. buildingId is null ");
						return null;
				}
                
                parameters += "?buildingid=" + buildingId;
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_UNIT + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{id:'8a47d2cc0c16c0014c0c5b13e2020e',name:'三单元'}, {id:'8a47d2ca4c0c10014c0c5b13e2020e',name:'二单元'}]";
                
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                //[{"rooms":[{"roomId":"0"},{"roomId":"1"},{"roomId":"2"}],"unitId":"0","unitName":"单元0号"},{"rooms":[{"roomId":"0"},{"roomId":"1"},{"roomId":"2"}],"unitId":"1","unitName":"单元1号"},{"rooms":[{"roomId":"0"},{"roomId":"1"},{"roomId":"2"}],"unitId":"2","unitName":"单元2号"}]
                JSONArray array = JSONArray.fromObject(returnVal);
                if(array.size() > 0) {
                	unit = new Unit[array.size()];
                	for (int i = 0; i < array.size(); i++) {
                		unit[i] = (Unit) JsonUtil.getObject(array.get(i).toString(), Unit.class);
					}
                }
				return unit;
		}
		
		/**
		 * 根据单元ID获取该单元下的所有房号
		 * @param unitId
		 * @return
		 */
		public static Room[] geRoomByUnitId(String unitId){
				
				Room[] room = null;
				String parameters = "" ;
                String returnVal = "";
				
                if(isNULL(unitId)){
						logger.error("input parameter error. unitId is null ");
						return null;
				}
                
                parameters += "?unitid=" + unitId;
                
                //returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_ROOM + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
                returnVal = "[{id:'8a47d2cc0c16c0014c0c5b13e2020e',name:'1302（室）'},{id:'8a47d2cc0c16c0014c0c5b13e2020e',name:'1202（室）'}]";
                logger.info("response : " + returnVal);
                //解析返回的Json字符串
                
                JSONArray array = JSONArray.fromObject(returnVal);
                if(array.size() > 0) {
                	room = new Room[array.size()];
                	for (int i = 0; i < array.size(); i++) {
                		room[i] = (Room) JsonUtil.getObject(array.get(i).toString(), Room.class);
					}
                }
				return room;
		}
		
		/**
		 * 为URL返回拼接后的参数字符串
		 * @param name 参数名
		 * @param value 参数值
		 * @return 
		 */
		private static String addParameter(String name, String value){
				if(value == null || value.equals("")){
						return name + "=";
				}
				return name + "=" + value;
		}
		
		/**
		 * 根据统一登录session中获取的username查询username对应的该用户的所有权限范围内的功能编号
		 * @param username
		 * @return
		 */
//		public static String[] getUserAuths(String username) {
//			
//			String parameters = "";
//			String returnVal = "";
//			  if(isNULL(username)){
//					logger.error("input parameter error. username is null ");
//					return null;
//			}
//          
//          parameters += "?username=" + username;
//          
//         // returnVal = HttpWebResponseUtility.httpWebResponse(URL1.URL_COMMUNITY_QUERY_UNIT + parameters, HttpWebResponseUtility.SEND_TYPE_GET);
//          returnVal = "[{\"resourceId\":\"8a47d2ca4a0b64fb014a0b7fc0890019\"},{\"resourceId\":\"8a47d2ca4a0b8a1f014a0baef016003e\"},{\"resourceId\":\"8a47d2ca4a0b8a1f014a0bafbeda003f\"}]";
//          logger.info("response : " + returnVal);
//          JSONArray array = JSONArray.fromObject(returnVal);
//          
//          
//          return (String[]) array.toArray();
//		}
		
		/**
		 * 检查参数是否为null或空字符串
		 * @param var
		 * @return
		 */
		private static boolean isNULL(String var){
				if(var == null || var.equals("")){
						return true;
				}
				return false;
		}
		
		public static void main(String[] args){
			String s = bind("11", "11122", "232", "3121", "aa", "sas", "ssa", "sasa", "sadsas");
			
			boolean b = createCommunity("sas", "sasasa");
			
			s = createRepair("sasa", "sasa", "sasa", "sasa", "sasaa", "sasa", "sasa");
			
			List<String> lis = getAuthListByRtxId("111");
			for (String string : lis) {
				System.out.println(string);
			}
			
			Building[] build =  getBuildingByOrgId("sasa");
			for (Building building : build) {
				System.out.println(building);
			}
			
			Community community = getCommunityDetail("sasa", "sasa");
			System.out.println(community.toString());
			
			CommunityInfo[] communities = getCommunityList();
			for (CommunityInfo communityInfo : communities) {
				System.out.println(communityInfo.toString());
			}
			
			Customer customer = getCustomerInfo("sasa", "sasa", "sasa");
			System.out.println(customer.toString());
			
			Org[] orgs = getOrgByYetaiId("sasa");
			for (Org org : orgs) {
				System.out.println(org.toString());
			}
			
			Repair repair = getRepairDetail("sasa");
			System.out.println(repair.toString());
			
			RepairInfo[] infos = getRepairInfoList("sasa", "sasa");
			for (RepairInfo repairInfo : infos) {
				System.out.println(repairInfo);
			}
			YeTai[] yetais = getYetaiByCommunityId("wqwq");
			for (YeTai yeTai : yetais) {
				System.out.println(yeTai.toString());
			}
			Unit[] units = geUnitByBuildingId("aaa");
			for (Unit unit : units) {
				System.out.println(unit.toString());
			}
			
			boolean bb = register("sasa", "sasa", "sasa", "sasa");
			System.out.println(bb);
			String str = subscribe("sasa", "sasa", null, "sasa", null, null, null, null, null, null, null);
			System.out.println(str);
			boolean b2 = unbind("sasa", "sasa");
			System.out.println(b2);
			boolean b3 = unsubscribe("sasa", "sasaa");
			System.out.println(b3);
			boolean b4 = updateCustomerInfo("sasa", "sasa", "sasasa", "sasa", "sasa", "sasa", "sasa", "sasa", "sasa", "sasa");
			System.out.println(b4);
			
		}
}
