package com.wx.wanda.csinterface.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;

public class HttpWebResponseUtility {
	
	private static Logger logger = Logger.getLogger(HttpWebResponseUtility.class);
	public static final String SEND_TYPE_GET  = "GET";
	public static final String SEND_TYPE_POST  = "POST";
	
	public static String httpWebResponse(String link,String sendType) {
		
		logger.info("Request URL :" + link);
		logger.info("Request Type :" + sendType);
		
		URL url ;
		HttpURLConnection conn;
		BufferedReader br;
		String line;
		StringBuffer respData;
		
		try {
				url = new URL(link);
				conn = (HttpURLConnection) url.openConnection();
				if(sendType == null ) {
						sendType = "GET";
			    }
				conn.setRequestMethod(sendType);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
				
				System.setProperty("sun.net.client.defaultConnectTimeout", "30000");
				System.setProperty("sun.net.client.defaultReadTimeout", "30000"); 
				
				conn.connect();
				
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(),"gbk"));
				respData = new StringBuffer();
				
				while((line = br.readLine()) != null){
						respData.append(line);
				}
				String str = respData.toString();
				logger.info("response data:" + str);
				return str;
		}catch (Exception ex) {
				logger.error(ex.getMessage());
				return null;
		}
		
	}

	public static void main(String[] args){
			String url = "http://192.168.253.4:8080/wdtest/TestServlet?id=1234&name=kuangxi";
			
			System.out.println("POST : " +httpWebResponse(url ,SEND_TYPE_POST));
			System.out.println("GET : " + httpWebResponse(url ,SEND_TYPE_GET));
	}
}
