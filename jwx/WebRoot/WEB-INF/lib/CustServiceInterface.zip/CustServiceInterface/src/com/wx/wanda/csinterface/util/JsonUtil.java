package com.wx.wanda.csinterface.util;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class JsonUtil {
		
		/**
		 * 将json字符串转为java对象
		 * @param jsonString
		 * @param clazz
		 * @return
		 */
		public static Object getObject(String jsonString, Class clazz){     
		        JSONObject jsonObject = null;     
		        try{     
		        		jsonObject = JSONObject.fromObject(jsonString);     
		        }catch(Exception e){     
		            e.printStackTrace();     
		        }     
		        return JSONObject.toBean(jsonObject, clazz);     
		 }     
		
		/**
		 * 将json字符串转为JSON对象
		 * @param jsonString
		 * @return
		 */
		public static JSONObject getJSONObject(String jsonString){
				JSONObject jsonObject = null;     
		        try{     
		        		jsonObject = JSONObject.fromObject(jsonString);   
		        }catch(Exception e){     
		            e.printStackTrace();     
		        }     
		        return jsonObject;
		}
		
		
		/**
		 * 将对象转为JSON字符串
		 * @param 
		 * @return
		 */
		public static String getJSONStr(Object obj){
				JSONObject jsonObject = null;     
		        try{     
		        		jsonObject = JSONObject.fromObject(obj);   
		        }catch(Exception e){     
		            e.printStackTrace();     
		        }     
		        return  jsonObject.toString() ;
		}
		
		/**
		 * 将对象数组转为JSON字符串
		 * @param 
		 * @return
		 */
		public static String getJSONStr(Object[] objs){
				JSONArray jsonArray = null;     
		        try{     
		        		jsonArray = JSONArray.fromObject(objs);   
		        }catch(Exception e){     
		            e.printStackTrace();     
		        }     
		        return jsonArray.toString();
		}
		
		/**
		 * 将JSON字符串转为JSONArray
		 * @param 
		 * @return
		 */
		public static JSONArray getJSONArray(String jsonStr){
				JSONArray jsonArray = null;     
		        try{     
		        		jsonArray = JSONArray.fromObject(jsonStr);   
		        }catch(Exception e){     
		            e.printStackTrace();     
		        }     
		        return jsonArray;
		}
		
		
		
		
		/**
		 * @param args
		 */
		public static void main(String[] args) {
			
		}

}
