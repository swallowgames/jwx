package com.wx.wanda.csinterface.util;

public class OPTIONTYPE {
		public static final String SUBSCRIBE_USER = "0";
		public static final String REGISTER_USER = "1";
		public static final String BIND_USER = "2";
}
