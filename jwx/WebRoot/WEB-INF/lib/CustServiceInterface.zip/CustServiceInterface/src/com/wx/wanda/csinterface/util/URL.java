package com.wx.wanda.csinterface.util;

public class URL {
		
		//=============================用户接口=======================================
		//获取用户权限列表
		public static final String URL_USER_AUTH_LIST = "http://ksfw.wanda.cn/weixin/wxAuthQuery";
		
		//=============================客户(粉丝)接口===================================
		//关注
		public static final String URL_CUST_SUBSCRIBE = "http://ksfw.wanda.cn/weixin/wxFanAttention"; 
		//取消关注
		public static final String URL_CUST_UNSUBSCRIBE = "http://ksfw.wanda.cn/weixin/wxFanUnAttention";
		//注册
		public static final String URL_CUST_REGISTER = "http://ksfw.wanda.cn/weixin/wxCusUpdate";
		//关联(绑定)
		public static final String URL_CUST_BIND = "http://ksfw.wanda.cn/weixin/wxCusBind";
		//取消关联(绑定)
		public static final String URL_CUST_UNBIND = "http://ksfw.wanda.cn/weixin/wxCusUnBind";
		//查询
		public static final String URL_CUST_QUERY = "http://ksfw.wanda.cn/weixin/wxCusQuery";
		//更新
		public static final String URL_CUST_UPDATE = "http://ksfw.wanda.cn/weixin/wxCusUpdate";
		
		//=============================小区接口=======================================
		//查询小区列表
		public static final String URL_COMMUNITY_LIST_QUERY = "http://ksfw.wanda.cn/weixin/wxCommuListQuery";
		//绑定小区微信号与小区ID（客诉平台创建小区）
		public static final String URL_COMMUNITY_CREATE= "http://ksfw.wanda.cn/weixin/wxAccountCreate";
		//查询小区详细
		public static final String URL_COMMUNITY_QUERY_DETAIL  = "http://ksfw.wanda.cn/weixin/wxCommuQuery";
		//根据小区ID查询业态信息
		public static final String URL_COMMUNITY_QUERY_YETAI = "http://ksfw.wanda.cn/weixin/wxQueryCommuYetai";
		//根据业态ID查询组团信息
		public static final String URL_COMMUNITY_QUERY_ORG = "http://ksfw.wanda.cn/weixin/wxQueryYetaiOrg";
		//根据组团ID查询楼栋信息
		public static final String URL_COMMUNITY_QUERY_BUILDING = "http://ksfw.wanda.cn/weixin/wxQueryOrgBuilding";
		//根据楼栋ID查询单元信息
		public static final String URL_COMMUNITY_QUERY_UNIT = "http://ksfw.wanda.cn/weixin/wxQueryBuildingUnit";
		//根据单元ID查询房号
		public static final String URL_COMMUNITY_QUERY_ROOM = "http://ksfw.wanda.cn/weixin/wxQueryRoomNo";
		
		//=============================报修接口=======================================
		//创建报修工单
		public static final String URL_REPAIR_CREATE = "http://ksfw.wanda.cn/weixin/wxCreaterRepairsSheet";
		//报修工单列表查询
		public static final String URL_REPAIR_QUERY_LIST = "http://ksfw.wanda.cn/weixin/wxListRepairsSheet";
		//报修工单详情查询
		public static final String URL_REPAIR_QUERY_DETAIL = "http://ksfw.wanda.cn/weixin/wxqueryRepairsSheet";
		
		
		
}
