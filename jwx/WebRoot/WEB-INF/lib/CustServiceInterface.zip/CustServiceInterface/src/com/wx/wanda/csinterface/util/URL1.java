package com.wx.wanda.csinterface.util;

public class URL1 {
		
		//=============================用户接口=======================================
		//获取用户权限列表
		public static final String URL_USER_AUTH_LIST = "http://10.199.201.135:8800/Complain/wxAuthQuery";
		
		//=============================客户(粉丝)接口===================================
		//关注
		public static final String URL_CUST_SUBSCRIBE = "http://10.199.201.135:8800/Complain/weixin/wxFanAttention"; 
		//取消关注
		public static final String URL_CUST_UNSUBSCRIBE = "http://10.199.201.135:8800/Complain/weixin/wxFanUnAttention";
		//注册
		public static final String URL_CUST_REGISTER = "http://10.199.201.135:8800/Complain/weixin/wxCusSave";
		//关联(绑定)
		public static final String URL_CUST_BIND = "http://10.199.201.135:8800/Complain/weixin/wxCusBind";
		//取消关联(绑定)
		public static final String URL_CUST_UNBIND = "http://10.199.201.135:8800/Complain/weixin/wxCusUnBind";
		//查询
		public static final String URL_CUST_QUERY = "http://10.199.201.135:8800/Complain/weixin/wxCusQuery";
		//更新
		public static final String URL_CUST_UPDATE = "http://10.199.201.135:8800/Complain/weixin/wxCusUpdate";
		
		//=============================小区接口=======================================
		//查询小区列表
		public static final String URL_COMMUNITY_LIST_QUERY = "http://10.199.201.135:8800/Complain/wxCommuListQuery";
		//绑定小区微信号与小区ID（客诉平台创建小区）
		public static final String URL_COMMUNITY_CREATE= "http://10.199.201.135:8800/Complain/wxAccountCreate";
		//查询小区详细
		public static final String URL_COMMUNITY_QUERY_DETAIL  = "http://10.199.201.135:8800/Complain/wxCommuQuery";
		//根据小区ID查询业态信息
		public static final String URL_COMMUNITY_QUERY_YETAI = "http://10.199.201.135:8800/Complain/wxQueryCommuYetai";
		//根据业态ID查询组团信息
		public static final String URL_COMMUNITY_QUERY_ORG = "http://10.199.201.135:8800/Complain/wxQueryYetaiOrg";
		//根据组团ID查询楼栋信息
		public static final String URL_COMMUNITY_QUERY_BUILDING = "http://10.199.201.135:8800/Complain/wxQueryOrgBuilding";
		//根据楼栋ID查询单元信息
		public static final String URL_COMMUNITY_QUERY_UNIT = "http://10.199.201.135:8800/Complain/wxQueryBuildingUnit";
		//根据单元ID查询房号
		public static final String URL_COMMUNITY_QUERY_ROOM = "http://10.199.201.135:8800/Complain/wxQueryRoomNo";
		
		//=============================报修接口=======================================
		//创建报修工单
		public static final String URL_REPAIR_CREATE = "http://10.199.201.135:8800/Complain/wxCreaterRepairsSheet";
		//报修工单列表查询
		public static final String URL_REPAIR_QUERY_LIST = "http://10.199.201.135:8800/Complain/wxListRepairsSheet";
		//报修工单详情查询
		public static final String URL_REPAIR_QUERY_DETAIL = "http://10.199.201.135:8800/Complain/wxqueryRepairsSheet";
		
		
		
}
